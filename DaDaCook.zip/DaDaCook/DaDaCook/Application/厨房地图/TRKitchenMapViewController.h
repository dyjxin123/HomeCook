//
//  TRKitchenMapViewController.h
//  DaDaCook
//
//  Created by tarena on 16/8/26.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TRKitchenMapViewController : UIViewController
@property (nonatomic) CLLocationCoordinate2D coordinate;
@end
